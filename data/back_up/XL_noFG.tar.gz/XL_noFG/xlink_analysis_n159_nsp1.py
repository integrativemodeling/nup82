import sys
from operator import itemgetter
import glob

##dictionary of names
#data = open('YeastSubunits.txt')
#D = data.readlines()
#data.close()

#DIC = {}
#DICr = {}
#for d in D:
#	d = d.strip().split()
#	DIC[d[0]] = d
#	DICr[d[3]] = d[0]

DICR={}

#######################################################################
## Read Sequences
#######################################################################
files=glob.glob("../Sequences/protein_fasta.*.txt")

#awk '{print $1, $3, $2, $4}' ../Crosslinks/Vif_Cul5_CBC_012315.txt > xl.txt
if len(files)==0: 
   print "no Sequence file found"
   exit()

DIC={}
for file in files:
    print file
    data = open(file)
    D = data.read().split('>')
    data.close()
    prot=file.split(".")[3]
    for d in D[1:]:
        d = d.replace('\r', '')
        d = d.split('\n')
    protein = prot
    seq = ''.join(d[1:])
    seq = seq.replace('*', '')
    DIC[protein] = [seq,len(seq)]
print DIC

#data = open('Xlinks.txt')
#D = data.readlines()
#data.close()

#######################################################################
## Crosslinks assignment
#######################################################################
f=open("XL_combined_skDSS_wtDSS_wtEDC.txt", "r")
string = f.read()
f.close()
xltext=string.split("\r")
print xltext

"""xltext='''Vif Vif 157 160
Rbx2 CUL5 1 455'''.split("\n")

xlintra='''aaa bbb 608 604
ccc ddd 308 319'''.split("\n")
"""
xlintra=""


#######################################################################
## Read array of Crosslinks assignment
#######################################################################
Xlinks = []

for xl in xltext:
    xlt=xl.split("\t")
    if (xlt != ['']):
        Xlinks.append((xlt[0],xlt[2],int(xlt[1]),int(xlt[3])))

for xl in xlintra:
    xlt=xl.split(" ")
    if (xlt != ['']):
        Xlinks.append((xlt[0],xlt[2],int(xlt[1])-1,int(xlt[3])-1))

'''
for d in D:
	if 'Order'!=d[:5] and '\t'!=d[0] and 'Same'!=d[:4]: 
		d = d.strip().split('\t')
		if len(d)>2:
			pr1, pr2 = d[1].split(')-')
			prot1,res1 = pr1.split('(')
			prot2,res2 = pr2[:-1].split('(')
			try: 
				r1 = DIC[DICr[prot1]][4][int(res1)-1]
				r2 = DIC[DICr[prot2]][4][int(res2)-1]
							
				Xlinks.append((prot1,prot2,int(res1)-1,int(res2)-1))
			except KeyError: pass
Xlinks = list(set(Xlinks))
'''

Proteins = DIC.keys()
lengths = [(i,int(DIC[i][-1])) for i in Proteins]
L = sorted(lengths, key=itemgetter(0), reverse=True)
#L = sorted(lengths, key=itemgetter(0), reverse=False)

print 'L =', L, 'Proteins =', Proteins
#exit()

Structures = []
SAXS = []
Disorder = []

#######################################################################
## X-ray Crystal Stuctures coverage
#######################################################################
Structures =   {'Dyn2':[(1,92,100.0,"4DS1_A")],
                'Nup82':[(1,452,100.0,"3PBP_A")],
                'NUP116':[(966,1113,99.0,"3PBP_B")],
                'Nup159':[(1,381,98.0,"1XIP_A"),(1117,1126,100.0,"4DS1_D"),(1424,1460,100.0,"3PBP_I")]}


"""
#######################################################################
## SAXS coverage
#######################################################################
SAXS =   {'Nsp1':[(633,823,50.0,"saxs")],
'NUP116':[(950,1113,50.0,"saxs")],
'Nup82':[(3,498,50.0,"saxs"),(572,690,50.0,"saxs")]}
"""

#######################################################################
## Disordered (predicted) regions
#######################################################################
Disorder = {'Dyn2':[(1,5)],
            'Nsp1':[(1,600)],
            'NUP116':[(1,962)],
            'Nup159':[(385,1116)]}


#######################################################################
## ??
#######################################################################
X,Y=[],[]
for link in Xlinks:
    p1,p2,r1,r2=link

    x = 0
    for i in L:
        if i[0]==p1: break
        else: x+=i[1]
    x += r1

    y = 0
    for i in L:
        if i[0]==p2: break
        else: y+=i[1]
    y += r2

    X.append(x)
    Y.append(y)


#######################################################################
## load library
#######################################################################
import matplotlib.pyplot as plt
from matplotlib.collections import PatchCollection
import matplotlib.path as mpath
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
import matplotlib
import numpy as np



fig = plt.figure(figsize = (11,11))
ax = fig.add_subplot(111)

t = 0
for l in L:
	t += l[1]
	ax.plot([t,t], [0,sum([i[1] for i in L])], 'k--')
	ax.plot([0,sum([i[1] for i in L])], [t,t], 'k--')

patches = []
colors = []
SRanges = []
TickPositions = []


#######################################################################
## X-ray Crystal Structures
#######################################################################
for strc in Structures:
	for frag in Structures[strc]:
		x = 0
		for i in L:
			if i[0]==strc: break
			else: x+=i[1]
		x+=frag[0]
		y = frag[1]-frag[0]
		print strc,x,y
		#art = mpatches.Rectangle((x,x),frag[1]-frag[0], frag[1]-frag[0], ec="none", linewidth=0, alpha=0.6)
		#patches.append(art)
		colors.append(frag[2])
		ax.broken_barh( [(x,y)], (x,y), linewidth=0, facecolors=matplotlib.cm.jet(frag[2]/100.), alpha=0.6  )
		SRanges += range(x,x+y+1)

for strc, length in L:
    print strc, " : ", length, "residues in total"
    xx=0	
    y=0
    for i in L:
        if i[0]==strc:
            y=i[1]
            break
        else: xx+=i[1]
    y+=xx
    TickPositions.append((y+xx)/2)


#######################################################################
## SAXS coverages
#######################################################################
for saxs in SAXS:
	for frag in SAXS[saxs]:
		x = 0
		for i in L:
			if i[0]==saxs: break
			else: x+=i[1]
		x+=frag[0]
		y = frag[1]-frag[0]
		print "saxs = ", saxs, ", ", x, ", ", y, ", ", frag[2]
		#art = mpatches.Rectangle((x,x),frag[1]-frag[0], frag[1]-frag[0], ec="none", linewidth=0, alpha=0.6)
		#patches.append(art)
		colors.append(frag[2])
		ax.broken_barh( [(x,y)], (x,y), linewidth=0, facecolors=matplotlib.cm.jet(frag[2]/100.), alpha=0.6  )
		SRanges += range(x,x+y+1)

		y = x+frag[1]-frag[0]
		ax.plot( [x,y], [x,y], 'b-', linewidth=1  )	

'''
for saxs, length in L:
	xx=0	
	y=0
	for i in L:
		if i[0]==saxs:
			y=i[1]
			break
		else: xx+=i[1]
	y+=xx
	TickPositions.append((y+xx)/2)
'''
#######################################################################
## Disordered Regions
#######################################################################
DRanges = []
for dis in Disorder:
	for frag in Disorder[dis]:
		x = 0
		for i in L:
			if i[0]==dis: break
			else: x+=i[1]
		x+=frag[0]
		y = x+frag[1]-frag[0]
		ax.plot( [x,y], [x,y], 'r-', linewidth=1  )	
		DRanges += range(x,y+1)


#collection = PatchCollection(patches, cmap=matplotlib.cm.jet, alpha=0.4)
#collection.set_array(np.array(colors))
#ax.add_collection(collection)


#######################################################################
## Crosslink Regions
#######################################################################
Xs,Ys = [],[]   #Structured + SAXS Region
Xd,Yd = [],[]   #Disordered Region
Xe,Ye = [],[]
for i in xrange(len(X)):
    if X[i] in SRanges and Y[i] in SRanges: 
        if X[i] >= Y[i]:
            Xs.append(X[i])
            Ys.append(Y[i])
        else:
            Xs.append(Y[i])
            Ys.append(X[i])	        
    elif X[i] in DRanges or Y[i] in DRanges:
        if X[i] >= Y[i]:	     
            Xd.append(X[i])
            Yd.append(Y[i])
        else:
            Xd.append(Y[i])
            Yd.append(X[i])	  	        
    else:
        if X[i] >= Y[i]:	
            Xe.append(X[i])
            Ye.append(Y[i])
        else:
            Xe.append(Y[i])
            Ye.append(X[i])	        
#print len(X), len(Y)
#print len(Xs+Xd+Xe), len(Ys+Yd+Ye)
#ax.scatter(Xe,Ye,c='blue',s=50,linewidth=0,alpha=0.9)
#ax.scatter(Ye,Xe,c='blue',s=50,linewidth=0,alpha=0.9)
### s=65 corresponds to ~50 residues
ax.scatter(Xe,Ye,c='blue',s=210,linewidth=0,alpha=0.1, marker="s")
ax.scatter(Ye,Xe,c='blue',s=210,linewidth=0,alpha=0.1, marker="s")
ax.scatter(Xs,Ys,c='green',s=210,linewidth=0,alpha=0.1, marker="s")
ax.scatter(Ys,Xs,c='green',s=210,linewidth=0,alpha=0.1, marker="s")
ax.scatter(Xd,Yd,c='red',s=210,linewidth=0,alpha=0.1, marker="s")
ax.scatter(Yd,Xd,c='red',s=210,linewidth=0,alpha=0.1, marker="s")

"""ax.scatter(Xe,Ye,c='black',s=50,linewidth=0,alpha=0.9)
ax.scatter(Xs,Ys,c='green',s=50,linewidth=0,alpha=0.9)
ax.scatter(Xd,Yd,c='red',s=50,linewidth=0,alpha=0.9)
"""

print L
plt.ylim((0,sum([i[1] for i in L])))
plt.xlim((0,sum([i[1] for i in L])))

ax2 = ax.twiny()

ax.set_yticks(TickPositions)
ax.tick_params(axis='y', labelsize=13)
ax.set_yticklabels([i[0] for i in L])

ax2.set_xticks(TickPositions)
ax2.tick_params(axis='x', labelsize=13)
#ax2.tick_params(axis='x', labelsize=9)
ax2.set_xticklabels([i[0] for i in L])

plt.show()
exit()

