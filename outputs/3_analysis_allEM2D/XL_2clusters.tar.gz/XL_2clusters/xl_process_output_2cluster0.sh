DIR_CLUSTER=../kmeans_10000_2/cluster.0_370
DIR_STAT=../../prefilter_allEM_chef9/kmeans_500_1/all_models.499
STAT_FIELDS=stat_fields0
STATS=stats0
flag=3

# step 1;
if [ $flag -le 1 ]; then
    echo "Step 1"
    for FILE in `ls -v $DIR_CLUSTER/*.rmf3`; do
        NAME=${FILE/$DIR_CLUSTER*-/}
        NAME=${NAME/.rmf3/}
        arr=(${NAME/_/ })
        #DIR_STAT=../prefilter_allEM${arr[0]}/kmeans_500_1/all_models.499
        #INDEX=${arr[1]}
        INDEX=$arr

        echo $FILE, $NAME, $DIR_STAT, $INDEX
        INDEX=$( expr $( expr $INDEX + 1 ) )

        LOG=${FILE/.rmf3/}
        process_output.py -f $DIR_STAT/stat.0.out -n $INDEX > $LOG.log
    done
    exit -1
fi


# step 2;
if [ $flag -le 2 ]; then
    echo "Step 2"
    rm -rf $STAT_FIELDS
    mkdir $STAT_FIELDS

    process_output.py -f $DIR_STAT/stat.0.out -p > $STAT_FIELDS.txt

    while read -r line
    do
        export FIELD=$line
        echo "$FIELD"

        for FILE in `ls -v $DIR_CLUSTER/*.log`; do
            awk '{if ($1 == ENVIRON["FIELD"]) print $2}' $FILE >> $STAT_FIELDS/$FIELD.log
        done
    done < $STAT_FIELDS.txt
    exit -1
fi


# step 3;
if [ $flag -le 3 ]; then
    echo "Step 3"
    # retrieve unique IDs for XL restraints
    awk 'BEGIN { FS = "," }; { printf "%d\n", $6 }' ~/n82/chef13_final_refinement/data/XL_wtNup82_DSS_standardized_no_FG_2copies_Ambiguity3.csv > xl_wtDSS.txt
    awk 'BEGIN { FS = "," }; { printf "%d\n", $6 }' ~/n82/chef13_final_refinement/data/XL_skNup82_DSS_standardized_equiv_no_FG_2copies_Ambiguity3.csv > xl_skDSS.txt
    awk 'BEGIN { FS = "," }; { printf "%d\n", $6 }' ~/n82/chef13_final_refinement/data/XL_wtNup82_EDC_standardized_no_FG_2copies_Ambiguity3.csv > xl_wtEDC.txt

    cat xl_wtDSS.txt > xl_temp.txt
    cat xl_skDSS.txt >> xl_temp.txt
    cat xl_wtEDC.txt >> xl_temp.txt

    sort -nk 1 xl_temp.txt | uniq > xl_uniq.txt
    rm -rf xl_temp.txt

    rm -rf $STATS
    mkdir $STATS

    # XL
    while read -r line
    do
        export uniqueID=${line/\n/}
        echo "uniqueID = $uniqueID"

        # determine number of XLs under the same unique ID
        i=0
        for FILE in `ls -v $STAT_FIELDS/ISD*_${uniqueID}-*.log`; do
            FILES[i]=$FILE
            i=$( expr $( expr $i + 1 ) )
        done
        if [ "$i" == "0" ]; then
            continue
        fi
        
        rm -rf temp_*.txt
        # print all distances under the same unique ID, separately for each model
        for ((j=0; j<$i; j++)); do
            echo $j, ${FILES[j]}
            
            export linenumber=0
            while read -r line
            do
                export linenumber=$( expr $( expr $linenumber + 1 ) )
                echo $line >> temp_$linenumber.txt
            done < ${FILES[j]}
        done
        
        # select the minimum distance
        for ((j=1; j<=$linenumber; j++)); do
            sort -nk 1 temp_$j.txt | head -n 1 >> $STATS/$uniqueID.txt
        done

        rm -rf temp_*.txt
        echo ""
    done < xl_uniq.txt
    #exit -1
fi


# step 4; finding averages and median
if [ $flag -le 4 ]; then
    echo "Step 4"
    rm -rf XL_$STATS.csv
    printf "uniqueID, median, average, min, max\n" >> XL_$STATS.csv 
    
    for FILE in `ls -v $STATS/*.txt`; do
        uniqueID=${FILE/$STATS\//}
        uniqueID=${uniqueID/.txt/}
        printf "$uniqueID, " >> XL_$STATS.csv        
        
        cat $FILE | perl -M'List::Util qw(sum max min)' -MPOSIX -0777 -a -ne 'printf "%g, %g, %g, %g\n", sum( (sort {$a<=>$b} @F)[ int( $#F/2 ), ceil( $#F/2 ) ] )/2, sum(@F)/@F, min(@F), max(@F);' >> XL_$STATS.csv
    done
fi

