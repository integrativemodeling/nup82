MODELLER=mod9.15
modelname=1GFL_sj
chain=B


respos=1
resname=VAL
$MODELLER mutate_model.py $modelname $respos $resname $chain
mv ${modelname}${resname}${respos}.pdb ${modelname}.pdb
rm -rf mutate_model.log


respos=65
resname=THR
$MODELLER mutate_model.py $modelname $respos $resname $chain
mv ${modelname}${resname}${respos}.pdb ${modelname}.pdb
rm -rf mutate_model.log

